print ("Operações disponíveis:"
    +"\n"+"1 soma"
    +"\n"+"2 subtração"
    +"\n"+"3 multiplicação"
    +"\n"+"4 divisão")
escolha = input("Escolha a operação: ")

if escolha in ['soma','Soma','1']:
    n1 = float(input("primeiro numero: "))
    n2 = float(input("segundo numero: "))
    r = n1 + n2
    print ("O resultado foi de:", r)

elif escolha in ['subtracao','Subtracao','2']:
    n1 = float(input("primeiro numero: "))
    n2 = float(input("segundo numero: "))
    r = n1 - n2
    print ("O resultado foi de:", r)


elif escolha in ['multiplicacao','Multiplicacao','3']:
    n1 = float(input("primeiro numero: "))
    n2 = float(input("segundo numero: "))
    r = n1 * n2
    print ("O resultado foi de:", r)

elif escolha in ['divisao','Divisao','4']:
    n1 = float(input("primeiro numero: "))
    n2 = float(input("segundo numero: "))
    r = n1 / n2
    print ("O resultado foi de:", r)
